#ifndef __HC04_H
#define __HC04_H



#endif