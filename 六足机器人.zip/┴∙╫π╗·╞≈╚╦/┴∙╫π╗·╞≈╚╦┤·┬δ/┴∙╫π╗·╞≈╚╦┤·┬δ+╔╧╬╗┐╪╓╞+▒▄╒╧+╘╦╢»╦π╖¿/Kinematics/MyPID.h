#include "stdio.h"
#include "stdint.h"
#ifndef __MYPID_H
#define __MYPID_H

int8_t ANGLE_PID_CONTROL(int8_t ANGLE_AIM,int8_t ANGLE_NOW);
//void servo_move(void);
//uint16_t Servo_Text(uint16_t *angle);

#endif
