#include "stdint.h"
#ifndef __LEG_H
#define __LEG_H

void Initial_StandingPos(void);//�������˶��ĳ�ʼ��λ��̬

/*֫�����*/
void Leg_A(float theta0,float theta1,float theta2,uint16_t time);
void Leg_B(float theta0,float theta1,float theta2,uint16_t time);
void Leg_C(float theta0,float theta1,float theta2,uint16_t time);
void Leg_D(float theta0,float theta1,float theta2,uint16_t time);
void Leg_E(float theta0,float theta1,float theta2,uint16_t time);
void Leg_F(float theta0,float theta1,float theta2,uint16_t time);
void Leg_ACE(float theta0,float theta1,float theta2,uint16_t time);
void Leg_BDF(float theta0,float theta1,float theta2,uint16_t time);
void Leg_ACE_Improve(float theta0_foreleg,float theta1_foreleg,float theta2_foreleg,
					 float theta0_middleleg,float theta1_middleleg,float theta2_middleleg,
					 float theta0_hindleg ,float theta1_hindleg,float theta2_hindleg,uint16_t time);
void Leg_BDF_Improve(float theta0_foreleg,float theta1_foreleg,float theta2_foreleg,
					 float theta0_middleleg,float theta1_middleleg,float theta2_middleleg,
					 float theta0_hindleg ,float theta1_hindleg,float theta2_hindleg,uint16_t time);
void Leg_Control_ALL_Improve(float thetaF0,float thetaF1,float thetaF2,
							 float thetaC0,float thetaC1,float thetaC2,
							 float thetaE0,float thetaE1,float thetaE2,
							 float thetaB0,float thetaB1,float thetaB2, 
							 float thetaD0,float thetaD1,float thetaD2,
							 float thetaA0,float thetaA1,float thetaA2,
							 uint16_t time);
					 
					 
#endif
