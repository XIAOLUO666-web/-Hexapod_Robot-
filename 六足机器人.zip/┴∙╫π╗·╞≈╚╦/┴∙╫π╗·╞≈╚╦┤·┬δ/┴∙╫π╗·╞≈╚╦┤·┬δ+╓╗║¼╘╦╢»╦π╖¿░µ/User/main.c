#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Serial_Servo.h"
#include "MPU6050.h"
#include "inv_mpu.h"
#include "FK_Action_Group.h"
#include "Mathematical.h"
#include "MyPID.h"
#include "Leg.h"
#include "Gait.h"

/*
//pitch��Y����ת��������������
//yaw��Z����ת��������ƫ����
//roll��X����ת��������������
*/
float Pitch,Roll,Yaw;

int main(void)
{
	Serial_Init();
	USART_DMA_Init();
	OLED_Init();

//	mpu_dmp_init();
	Gait_Init();
	mpu_dmp_init();

//	OLED_ShowString(2,1,"Pitch:");
//	OLED_ShowString(3,1,"Roll:");
//	OLED_ShowString(4,1,"Yaw:");



//		Body_Move(0,0,30);
//		for(uint8_t i = 0;i <= 3;i++)
//		{
			
//		}
//		delay_ms(100);
//		for(uint8_t i = 0;i <= 8;i++)
//		{
//			Y_LTrans_Gait();
//		}
//		Gait_Init();
//		for(uint8_t i = 0;i <= 6;i++)
//		{
//			TurnLeft_Gait();
//		}
//		Gait_Init();
//		for(uint8_t i = 1;i <= 21;i++)
//		{
//			TurnRight_Gait();
//			delay_ms(3000);
//		}
//		for(uint8_t i = 0;i <= 3;i++)
//		{
//		X_Back_Gait();
//		}
//		Gait_Init();		
//		for(uint8_t i = 0;i <= 7;i++)
//		{
//			Y_RTrans_Gait();
//		}	
//		Gait_Init();
	
	while(1)
	{
//		Body_Move(60,0,-20);
//		Body_Move(0,20,0);
//		Body_Move(-60,0,-20);
//		Body_Move(0,-20,0);
//		Body_Move(40,0,30);
//		Body_Move(-40,0,30);
//		Body_Move(0,40,30);
//		Body_Move(0,-40,30);
//		for(uint8_t i = 0;i <= 10;i++)
//		{
//		Body_Move(60,0,20);

//		Body_Move(-60,0,20);
//	
//		Body_Move(0,40,20);

//		Body_Move(0,-40,20);	
//		}
//		for(uint8_t i = 0;i <= 8;i++)
//		{
//			Y_LTrans_Gait();
//		}
//		for(uint8_t i = 0;i <= 6;i++)
//		{
//			TurnLeft_Gait();
//		}
//		for(uint8_t i = 0;i <= 6;i++)
//		{
//			TurnRight_Gait();
//		}
//		for(uint8_t i = 0;i <= 7;i++)
//		{
//			X_Back_Gait();
//		}		
//		for(uint8_t i = 0;i <= 7;i++)
//		{
//			Y_RTrans_Gait();
//		}	

		mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
		OLED_ShowSignedNum(2,7,Pitch,3);
		OLED_ShowSignedNum(3,7,Roll,3);
		OLED_ShowSignedNum(4,7,Yaw,3);
		Body_Balance();
	}
}

