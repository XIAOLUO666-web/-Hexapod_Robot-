#ifndef __HCSR04_H
#define __HCSR04_H


#endif